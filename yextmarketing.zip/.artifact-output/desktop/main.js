/******/ (() => { // webpackBootstrap
/******/ 	var __webpack_modules__ = ({

/***/ "./src/images/address.svg":
/*!********************************!*\
  !*** ./src/images/address.svg ***!
  \********************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (__webpack_require__.p + "images/address.svg");

/***/ }),

/***/ "./src/images/banner.webp":
/*!********************************!*\
  !*** ./src/images/banner.webp ***!
  \********************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (__webpack_require__.p + "images/banner.webp");

/***/ }),

/***/ "./src/images/left-arrow.svg":
/*!***********************************!*\
  !*** ./src/images/left-arrow.svg ***!
  \***********************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (__webpack_require__.p + "images/left-arrow.svg");

/***/ }),

/***/ "./src/images/location.jpg":
/*!*********************************!*\
  !*** ./src/images/location.jpg ***!
  \*********************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (__webpack_require__.p + "images/location.jpg");

/***/ }),

/***/ "./src/images/logo.png":
/*!*****************************!*\
  !*** ./src/images/logo.png ***!
  \*****************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (__webpack_require__.p + "images/logo.png");

/***/ }),

/***/ "./src/images/luxurystore.jpeg":
/*!*************************************!*\
  !*** ./src/images/luxurystore.jpeg ***!
  \*************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (__webpack_require__.p + "images/luxurystore.jpeg");

/***/ }),

/***/ "./src/images/phone.svg":
/*!******************************!*\
  !*** ./src/images/phone.svg ***!
  \******************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (__webpack_require__.p + "images/phone.svg");

/***/ }),

/***/ "./src/images/right-arrow.svg":
/*!************************************!*\
  !*** ./src/images/right-arrow.svg ***!
  \************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (__webpack_require__.p + "images/right-arrow.svg");

/***/ }),

/***/ "./src/images/slide.webp":
/*!*******************************!*\
  !*** ./src/images/slide.webp ***!
  \*******************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (__webpack_require__.p + "images/slide.webp");

/***/ }),

/***/ "./src/images/time.svg":
/*!*****************************!*\
  !*** ./src/images/time.svg ***!
  \*****************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (__webpack_require__.p + "images/time.svg");

/***/ }),

/***/ "./src/images/yext-favicon.png":
/*!*************************************!*\
  !*** ./src/images/yext-favicon.png ***!
  \*************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (__webpack_require__.p + "images/yext-favicon.png");

/***/ }),

/***/ "./src/images/yext-logo.svg":
/*!**********************************!*\
  !*** ./src/images/yext-logo.svg ***!
  \**********************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (__webpack_require__.p + "images/yext-logo.svg");

/***/ }),

/***/ "./src/main.css":
/*!**********************!*\
  !*** ./src/main.css ***!
  \**********************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
// extracted by mini-css-extract-plugin


/***/ }),

/***/ "./src/locator/time.ts":
/*!*****************************!*\
  !*** ./src/locator/time.ts ***!
  \*****************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "formatOpenNowString": () => (/* binding */ formatOpenNowString),
/* harmony export */   "parseTimeZoneUtcOffset": () => (/* binding */ parseTimeZoneUtcOffset)
/* harmony export */ });
// Formats hours function
// Open · Closes at 5pm
// Closed · Open at 6am
function formatOpenNowString(hoursData, utcOffset) {
  var now = getYextTimeWithUtcOffset(utcOffset);
  var tomorrow = new Date(now.getTime() + 60 * 60 * 24 * 1000);
  var yesterday = new Date(now.getTime() - 60 * 60 * 24 * 1000);
  var nowTimeNumber = now.getHours() + now.getMinutes() / 60;
  var intervalsToday = getIntervalOnDate(now, hoursData);
  var intervalsTomorrow = getIntervalOnDate(tomorrow, hoursData);
  var intervalsYesterday = getIntervalOnDate(yesterday, hoursData);
  var openRightNow = false;
  var currentInterval = null;
  var nextInterval = null;

  if (intervalsYesterday) {
    for (var i = 0; i < intervalsYesterday.length; i++) {
      var interval = intervalsYesterday[i];
      var startIntervalNumber = timeStringToNumber(interval.start);
      var endIntervalNumber = timeStringToNumber(interval.end); // If end overflows to the next day (i.e. today).

      if (endIntervalNumber < startIntervalNumber) {
        if (nowTimeNumber < endIntervalNumber) {
          currentInterval = interval;
          openRightNow = true;
        }
      }
    }
  } // Assumes no overlapping intervals


  if (intervalsToday) {
    for (var i = 0; i < intervalsToday.length; i++) {
      var interval = intervalsToday[i];
      var startIntervalNumber = timeStringToNumber(interval.start);
      var endIntervalNumber = timeStringToNumber(interval.end); // If current time doesn't belong to one of yesterdays interval.

      if (currentInterval == null) {
        if (endIntervalNumber < startIntervalNumber) {
          if (nowTimeNumber >= startIntervalNumber) {
            currentInterval = interval;
            openRightNow = true;
          }
        } else if (nowTimeNumber >= startIntervalNumber && nowTimeNumber < endIntervalNumber) {
          currentInterval = interval;
          openRightNow = true;
        }
      }

      if (nextInterval == null) {
        if (startIntervalNumber > nowTimeNumber) {
          nextInterval = interval;
        }
      } else {
        if (startIntervalNumber > nowTimeNumber && startIntervalNumber < timeStringToNumber(nextInterval.start)) {
          nextInterval = interval;
        }
      }
    }
  }

  var nextIsTomorrow = false; // If no more intervals in the day

  if (nextInterval == null) {
    if (intervalsTomorrow) {
      if (intervalsTomorrow.length > 0) {
        nextInterval = intervalsTomorrow[0];
        nextIsTomorrow = true;
      }
    }
  }

  var hoursString = "";

  if (nextInterval) {
    if (openRightNow) {
      // Check first for a 24-hour interval, then check for open past midnight
      if (currentInterval.start == "00:00" && currentInterval.end == "23:59") {
        hoursString += "<strong>Open 24 hours</strong>";
      } else if (nextInterval.start == "00:00" && currentInterval.end == "23:59") {
        hoursString += "<strong>Open</strong> · Closes at [closingTime] tomorrow";
        hoursString = hoursString.replace("[closingTime]", // formatTime(currentInterval.end)
        currentInterval.end);
      } else {
        hoursString += "<strong>Open</strong> · Closes at [closingTime]";
        hoursString = hoursString.replace("[closingTime]", // formatTime(currentInterval.end)
        currentInterval.end);
      }
    } else {
      if (nextIsTomorrow) {
        hoursString += "<strong>Closed</strong> · Opens at [openingTime] tomorrow";
        hoursString = hoursString.replace("[openingTime]", // formatTime(nextInterval.start)
        nextInterval.start);
      } else {
        hoursString += "<strong>Closed</strong> · Opens at [openingTime]";
        hoursString = hoursString.replace("[openingTime]", // formatTime(nextInterval.start)
        nextInterval.start);
      }
    }
  }

  return hoursString;
}

function formatTime(time) {
  var tempDate = new Date("January 1, 2020 " + time);
  var localeString = "en-US";
  return tempDate.toLocaleTimeString(localeString.replace("_", "-"), {
    hour: "numeric",
    minute: "numeric"
  });
}

function timeStringToNumber(timeString) {
  var parts = timeString.split(":");
  var hours = parseInt(parts[0].replace(/\u200E/g, ""), 10);
  var minutes = parseInt(parts[1].replace(/\u200E/g, ""), 10);
  return hours + minutes / 60;
}

function getYextTimeWithUtcOffset(entityUtcOffsetSeconds) {
  var now = new Date();
  var utcOffset = 0;

  if (entityUtcOffsetSeconds) {
    utcOffset = entityUtcOffsetSeconds * 1000;
  }

  if (utcOffset !== 0) {
    var localUtcOffset = now.getTimezoneOffset() * 60 * 1000;
    return new Date(now.valueOf() + utcOffset + localUtcOffset);
  }

  return now;
} // Parses an offset formatted like {+/-}{04}:{00}


function parseTimeZoneUtcOffset(timeString) {
  if (!timeString) {
    return 0;
  }

  var parts = timeString.split(":");
  var hours = parseInt(parts[0].replace(/\u200E/g, ""), 10);
  var minutes = parseInt(parts[1].replace(/\u200E/g, ""), 10);

  if (hours < 0) {
    return -(Math.abs(hours) + minutes / 60) * 60 * 60;
  }

  return (hours + minutes / 60) * 60 * 60;
}

function getIntervalOnDate(date, hoursData) {
  var day = date.getDate();
  var month = date.getMonth() + 1;
  var year = date.getFullYear();
  var days = ["sunday", "monday", "tuesday", "wednesday", "thursday", "friday", "saturday"];
  var dateString = year + "-" + (month < 10 ? "0" + month : month) + "-" + (day < 10 ? "0" + day : day);
  var dayOfWeekString = days[date.getDay()]; // Check for holiday

  if (hoursData.holidayHours) {
    for (var i = 0; i < hoursData.holidayHours.length; i++) {
      var holiday = hoursData.holidayHours[i];

      if (holiday.date == dateString) {
        if (holiday.openIntervals) {
          return holiday.openIntervals;
        } else if (holiday.isClosed === true) {
          return null; // On holiday but closed
        }
      }
    }
  } // Not on holiday


  if (hoursData[dayOfWeekString] && hoursData[dayOfWeekString].openIntervals) {
    return hoursData[dayOfWeekString].openIntervals;
  } else {
    return null;
  }
}

/***/ }),

/***/ "./src/images sync \\.(png|jpe?g|svg|webp|jpg)$":
/*!*******************************************************************!*\
  !*** ./src/images/ sync nonrecursive \.(png|jpe?g|svg|webp|jpg)$ ***!
  \*******************************************************************/
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

var map = {
	"./address.svg": "./src/images/address.svg",
	"./banner.webp": "./src/images/banner.webp",
	"./left-arrow.svg": "./src/images/left-arrow.svg",
	"./location.jpg": "./src/images/location.jpg",
	"./logo.png": "./src/images/logo.png",
	"./luxurystore.jpeg": "./src/images/luxurystore.jpeg",
	"./phone.svg": "./src/images/phone.svg",
	"./right-arrow.svg": "./src/images/right-arrow.svg",
	"./slide.webp": "./src/images/slide.webp",
	"./time.svg": "./src/images/time.svg",
	"./yext-favicon.png": "./src/images/yext-favicon.png",
	"./yext-logo.svg": "./src/images/yext-logo.svg"
};


function webpackContext(req) {
	var id = webpackContextResolve(req);
	return __webpack_require__(id);
}
function webpackContextResolve(req) {
	if(!__webpack_require__.o(map, req)) {
		var e = new Error("Cannot find module '" + req + "'");
		e.code = 'MODULE_NOT_FOUND';
		throw e;
	}
	return map[req];
}
webpackContext.keys = function webpackContextKeys() {
	return Object.keys(map);
};
webpackContext.resolve = webpackContextResolve;
module.exports = webpackContext;
webpackContext.id = "./src/images sync \\.(png|jpe?g|svg|webp|jpg)$";

/***/ })

/******/ 	});
/************************************************************************/
/******/ 	// The module cache
/******/ 	var __webpack_module_cache__ = {};
/******/ 	
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/ 		// Check if module is in cache
/******/ 		var cachedModule = __webpack_module_cache__[moduleId];
/******/ 		if (cachedModule !== undefined) {
/******/ 			return cachedModule.exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = __webpack_module_cache__[moduleId] = {
/******/ 			// no module.id needed
/******/ 			// no module.loaded needed
/******/ 			exports: {}
/******/ 		};
/******/ 	
/******/ 		// Execute the module function
/******/ 		__webpack_modules__[moduleId](module, module.exports, __webpack_require__);
/******/ 	
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/ 	
/************************************************************************/
/******/ 	/* webpack/runtime/define property getters */
/******/ 	(() => {
/******/ 		// define getter functions for harmony exports
/******/ 		__webpack_require__.d = (exports, definition) => {
/******/ 			for(var key in definition) {
/******/ 				if(__webpack_require__.o(definition, key) && !__webpack_require__.o(exports, key)) {
/******/ 					Object.defineProperty(exports, key, { enumerable: true, get: definition[key] });
/******/ 				}
/******/ 			}
/******/ 		};
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/global */
/******/ 	(() => {
/******/ 		__webpack_require__.g = (function() {
/******/ 			if (typeof globalThis === 'object') return globalThis;
/******/ 			try {
/******/ 				return this || new Function('return this')();
/******/ 			} catch (e) {
/******/ 				if (typeof window === 'object') return window;
/******/ 			}
/******/ 		})();
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/hasOwnProperty shorthand */
/******/ 	(() => {
/******/ 		__webpack_require__.o = (obj, prop) => (Object.prototype.hasOwnProperty.call(obj, prop))
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/make namespace object */
/******/ 	(() => {
/******/ 		// define __esModule on exports
/******/ 		__webpack_require__.r = (exports) => {
/******/ 			if(typeof Symbol !== 'undefined' && Symbol.toStringTag) {
/******/ 				Object.defineProperty(exports, Symbol.toStringTag, { value: 'Module' });
/******/ 			}
/******/ 			Object.defineProperty(exports, '__esModule', { value: true });
/******/ 		};
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/publicPath */
/******/ 	(() => {
/******/ 		var scriptUrl;
/******/ 		if (__webpack_require__.g.importScripts) scriptUrl = __webpack_require__.g.location + "";
/******/ 		var document = __webpack_require__.g.document;
/******/ 		if (!scriptUrl && document) {
/******/ 			if (document.currentScript)
/******/ 				scriptUrl = document.currentScript.src
/******/ 			if (!scriptUrl) {
/******/ 				var scripts = document.getElementsByTagName("script");
/******/ 				if(scripts.length) scriptUrl = scripts[scripts.length - 1].src
/******/ 			}
/******/ 		}
/******/ 		// When supporting browsers where an automatic publicPath is not supported you must specify an output.publicPath manually via configuration
/******/ 		// or pass an empty string ("") and set the __webpack_public_path__ variable from your code to use your own logic.
/******/ 		if (!scriptUrl) throw new Error("Automatic publicPath is not supported in this browser");
/******/ 		scriptUrl = scriptUrl.replace(/#.*$/, "").replace(/\?.*$/, "").replace(/\/[^\/]+$/, "/");
/******/ 		__webpack_require__.p = scriptUrl;
/******/ 	})();
/******/ 	
/************************************************************************/
var __webpack_exports__ = {};
// This entry need to be wrapped in an IIFE because it need to be in strict mode.
(() => {
"use strict";
/*!*********************!*\
  !*** ./src/main.js ***!
  \*********************/
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _main_css__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./main.css */ "./src/main.css");
/* harmony import */ var _src_locator_time__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../../../src/locator/time */ "./src/locator/time.ts");



function importAll(r) {
  var images = {};
  r.keys().map(function (item, index) {
    images[item.replace('./', '')] = r(item);
  });
  return images;
}

var images = importAll(__webpack_require__("./src/images sync \\.(png|jpe?g|svg|webp|jpg)$")); // const css = importAll(require.context('./css', false, /\.(css)$/));
})();

/******/ })()
;
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly9zaXRlcy1sb2NhdGlvbnMtc3RhcnRlci8uL3NyYy9pbWFnZXMvYWRkcmVzcy5zdmciLCJ3ZWJwYWNrOi8vc2l0ZXMtbG9jYXRpb25zLXN0YXJ0ZXIvLi9zcmMvaW1hZ2VzL2Jhbm5lci53ZWJwIiwid2VicGFjazovL3NpdGVzLWxvY2F0aW9ucy1zdGFydGVyLy4vc3JjL2ltYWdlcy9sZWZ0LWFycm93LnN2ZyIsIndlYnBhY2s6Ly9zaXRlcy1sb2NhdGlvbnMtc3RhcnRlci8uL3NyYy9pbWFnZXMvbG9jYXRpb24uanBnIiwid2VicGFjazovL3NpdGVzLWxvY2F0aW9ucy1zdGFydGVyLy4vc3JjL2ltYWdlcy9sb2dvLnBuZyIsIndlYnBhY2s6Ly9zaXRlcy1sb2NhdGlvbnMtc3RhcnRlci8uL3NyYy9pbWFnZXMvbHV4dXJ5c3RvcmUuanBlZyIsIndlYnBhY2s6Ly9zaXRlcy1sb2NhdGlvbnMtc3RhcnRlci8uL3NyYy9pbWFnZXMvcGhvbmUuc3ZnIiwid2VicGFjazovL3NpdGVzLWxvY2F0aW9ucy1zdGFydGVyLy4vc3JjL2ltYWdlcy9yaWdodC1hcnJvdy5zdmciLCJ3ZWJwYWNrOi8vc2l0ZXMtbG9jYXRpb25zLXN0YXJ0ZXIvLi9zcmMvaW1hZ2VzL3NsaWRlLndlYnAiLCJ3ZWJwYWNrOi8vc2l0ZXMtbG9jYXRpb25zLXN0YXJ0ZXIvLi9zcmMvaW1hZ2VzL3RpbWUuc3ZnIiwid2VicGFjazovL3NpdGVzLWxvY2F0aW9ucy1zdGFydGVyLy4vc3JjL2ltYWdlcy95ZXh0LWZhdmljb24ucG5nIiwid2VicGFjazovL3NpdGVzLWxvY2F0aW9ucy1zdGFydGVyLy4vc3JjL2ltYWdlcy95ZXh0LWxvZ28uc3ZnIiwid2VicGFjazovL3NpdGVzLWxvY2F0aW9ucy1zdGFydGVyLy4vc3JjL21haW4uY3NzIiwid2VicGFjazovL3NpdGVzLWxvY2F0aW9ucy1zdGFydGVyLy4vc3JjL2xvY2F0b3IvdGltZS50cyIsIndlYnBhY2s6Ly9zaXRlcy1sb2NhdGlvbnMtc3RhcnRlci8uL3NyYy9pbWFnZXN8c3luY3xub25yZWN1cnNpdmV8Ly4ocG5nfGpwZSIsIndlYnBhY2s6Ly9zaXRlcy1sb2NhdGlvbnMtc3RhcnRlci93ZWJwYWNrL2Jvb3RzdHJhcCIsIndlYnBhY2s6Ly9zaXRlcy1sb2NhdGlvbnMtc3RhcnRlci93ZWJwYWNrL3J1bnRpbWUvZGVmaW5lIHByb3BlcnR5IGdldHRlcnMiLCJ3ZWJwYWNrOi8vc2l0ZXMtbG9jYXRpb25zLXN0YXJ0ZXIvd2VicGFjay9ydW50aW1lL2dsb2JhbCIsIndlYnBhY2s6Ly9zaXRlcy1sb2NhdGlvbnMtc3RhcnRlci93ZWJwYWNrL3J1bnRpbWUvaGFzT3duUHJvcGVydHkgc2hvcnRoYW5kIiwid2VicGFjazovL3NpdGVzLWxvY2F0aW9ucy1zdGFydGVyL3dlYnBhY2svcnVudGltZS9tYWtlIG5hbWVzcGFjZSBvYmplY3QiLCJ3ZWJwYWNrOi8vc2l0ZXMtbG9jYXRpb25zLXN0YXJ0ZXIvd2VicGFjay9ydW50aW1lL3B1YmxpY1BhdGgiLCJ3ZWJwYWNrOi8vc2l0ZXMtbG9jYXRpb25zLXN0YXJ0ZXIvLi9zcmMvbWFpbi5qcyJdLCJuYW1lcyI6WyJfX3dlYnBhY2tfcHVibGljX3BhdGhfXyIsImltcG9ydEFsbCIsInIiLCJpbWFnZXMiLCJrZXlzIiwibWFwIiwiaXRlbSIsImluZGV4IiwicmVwbGFjZSIsInJlcXVpcmUiXSwibWFwcGluZ3MiOiI7Ozs7Ozs7Ozs7Ozs7O0FBQUEsaUVBQWVBLHFCQUF1QixHQUFHLG9CQUF6QyxFOzs7Ozs7Ozs7Ozs7Ozs7QUNBQSxpRUFBZUEscUJBQXVCLEdBQUcsb0JBQXpDLEU7Ozs7Ozs7Ozs7Ozs7OztBQ0FBLGlFQUFlQSxxQkFBdUIsR0FBRyx1QkFBekMsRTs7Ozs7Ozs7Ozs7Ozs7O0FDQUEsaUVBQWVBLHFCQUF1QixHQUFHLHFCQUF6QyxFOzs7Ozs7Ozs7Ozs7Ozs7QUNBQSxpRUFBZUEscUJBQXVCLEdBQUcsaUJBQXpDLEU7Ozs7Ozs7Ozs7Ozs7OztBQ0FBLGlFQUFlQSxxQkFBdUIsR0FBRyx5QkFBekMsRTs7Ozs7Ozs7Ozs7Ozs7O0FDQUEsaUVBQWVBLHFCQUF1QixHQUFHLGtCQUF6QyxFOzs7Ozs7Ozs7Ozs7Ozs7QUNBQSxpRUFBZUEscUJBQXVCLEdBQUcsd0JBQXpDLEU7Ozs7Ozs7Ozs7Ozs7OztBQ0FBLGlFQUFlQSxxQkFBdUIsR0FBRyxtQkFBekMsRTs7Ozs7Ozs7Ozs7Ozs7O0FDQUEsaUVBQWVBLHFCQUF1QixHQUFHLGlCQUF6QyxFOzs7Ozs7Ozs7Ozs7Ozs7QUNBQSxpRUFBZUEscUJBQXVCLEdBQUcseUJBQXpDLEU7Ozs7Ozs7Ozs7Ozs7OztBQ0FBLGlFQUFlQSxxQkFBdUIsR0FBRyxzQkFBekMsRTs7Ozs7Ozs7Ozs7O0FDQUE7Ozs7Ozs7Ozs7Ozs7Ozs7O0FDQUE7QUFDQTtBQUNBO0FBQ00sU0FBVSxtQkFBVixDQUE4QixTQUE5QixFQUF5QyxTQUF6QyxFQUFrRDtBQUN0RCxNQUFNLEdBQUcsR0FBRyx3QkFBd0IsQ0FBQyxTQUFELENBQXBDO0FBRUEsTUFBTSxRQUFRLEdBQUcsSUFBSSxJQUFKLENBQVMsR0FBRyxDQUFDLE9BQUosS0FBZ0IsS0FBSyxFQUFMLEdBQVUsRUFBVixHQUFlLElBQXhDLENBQWpCO0FBQ0EsTUFBTSxTQUFTLEdBQUcsSUFBSSxJQUFKLENBQVMsR0FBRyxDQUFDLE9BQUosS0FBZ0IsS0FBSyxFQUFMLEdBQVUsRUFBVixHQUFlLElBQXhDLENBQWxCO0FBQ0EsTUFBTSxhQUFhLEdBQUcsR0FBRyxDQUFDLFFBQUosS0FBaUIsR0FBRyxDQUFDLFVBQUosS0FBbUIsRUFBMUQ7QUFFQSxNQUFNLGNBQWMsR0FBRyxpQkFBaUIsQ0FBQyxHQUFELEVBQU0sU0FBTixDQUF4QztBQUNBLE1BQU0saUJBQWlCLEdBQUcsaUJBQWlCLENBQUMsUUFBRCxFQUFXLFNBQVgsQ0FBM0M7QUFDQSxNQUFNLGtCQUFrQixHQUFHLGlCQUFpQixDQUFDLFNBQUQsRUFBWSxTQUFaLENBQTVDO0FBQ0EsTUFBSSxZQUFZLEdBQUcsS0FBbkI7QUFDQSxNQUFJLGVBQWUsR0FBRyxJQUF0QjtBQUNBLE1BQUksWUFBWSxHQUFHLElBQW5COztBQUVBLE1BQUksa0JBQUosRUFBd0I7QUFDdEIsU0FBSyxJQUFJLENBQUMsR0FBRyxDQUFiLEVBQWdCLENBQUMsR0FBRyxrQkFBa0IsQ0FBQyxNQUF2QyxFQUErQyxDQUFDLEVBQWhELEVBQW9EO0FBQ2xELFVBQU0sUUFBUSxHQUFHLGtCQUFrQixDQUFDLENBQUQsQ0FBbkM7QUFDQSxVQUFNLG1CQUFtQixHQUFHLGtCQUFrQixDQUFDLFFBQVEsQ0FBQyxLQUFWLENBQTlDO0FBQ0EsVUFBTSxpQkFBaUIsR0FBRyxrQkFBa0IsQ0FBQyxRQUFRLENBQUMsR0FBVixDQUE1QyxDQUhrRCxDQUtsRDs7QUFDQSxVQUFJLGlCQUFpQixHQUFHLG1CQUF4QixFQUE2QztBQUMzQyxZQUFJLGFBQWEsR0FBRyxpQkFBcEIsRUFBdUM7QUFDckMseUJBQWUsR0FBRyxRQUFsQjtBQUNBLHNCQUFZLEdBQUcsSUFBZjtBQUNEO0FBQ0Y7QUFDRjtBQUNGLEdBNUJxRCxDQThCdEQ7OztBQUNBLE1BQUksY0FBSixFQUFvQjtBQUNsQixTQUFLLElBQUksQ0FBQyxHQUFHLENBQWIsRUFBZ0IsQ0FBQyxHQUFHLGNBQWMsQ0FBQyxNQUFuQyxFQUEyQyxDQUFDLEVBQTVDLEVBQWdEO0FBQzlDLFVBQU0sUUFBUSxHQUFHLGNBQWMsQ0FBQyxDQUFELENBQS9CO0FBQ0EsVUFBTSxtQkFBbUIsR0FBRyxrQkFBa0IsQ0FBQyxRQUFRLENBQUMsS0FBVixDQUE5QztBQUNBLFVBQU0saUJBQWlCLEdBQUcsa0JBQWtCLENBQUMsUUFBUSxDQUFDLEdBQVYsQ0FBNUMsQ0FIOEMsQ0FLOUM7O0FBQ0EsVUFBSSxlQUFlLElBQUksSUFBdkIsRUFBNkI7QUFDM0IsWUFBSSxpQkFBaUIsR0FBRyxtQkFBeEIsRUFBNkM7QUFDM0MsY0FBSSxhQUFhLElBQUksbUJBQXJCLEVBQTBDO0FBQ3hDLDJCQUFlLEdBQUcsUUFBbEI7QUFDQSx3QkFBWSxHQUFHLElBQWY7QUFDRDtBQUNGLFNBTEQsTUFLTyxJQUNMLGFBQWEsSUFBSSxtQkFBakIsSUFDQSxhQUFhLEdBQUcsaUJBRlgsRUFHTDtBQUNBLHlCQUFlLEdBQUcsUUFBbEI7QUFDQSxzQkFBWSxHQUFHLElBQWY7QUFDRDtBQUNGOztBQUVELFVBQUksWUFBWSxJQUFJLElBQXBCLEVBQTBCO0FBQ3hCLFlBQUksbUJBQW1CLEdBQUcsYUFBMUIsRUFBeUM7QUFDdkMsc0JBQVksR0FBRyxRQUFmO0FBQ0Q7QUFDRixPQUpELE1BSU87QUFDTCxZQUNFLG1CQUFtQixHQUFHLGFBQXRCLElBQ0EsbUJBQW1CLEdBQUcsa0JBQWtCLENBQUMsWUFBWSxDQUFDLEtBQWQsQ0FGMUMsRUFHRTtBQUNBLHNCQUFZLEdBQUcsUUFBZjtBQUNEO0FBQ0Y7QUFDRjtBQUNGOztBQUVELE1BQUksY0FBYyxHQUFHLEtBQXJCLENBcEVzRCxDQXNFdEQ7O0FBQ0EsTUFBSSxZQUFZLElBQUksSUFBcEIsRUFBMEI7QUFDeEIsUUFBSSxpQkFBSixFQUF1QjtBQUNyQixVQUFJLGlCQUFpQixDQUFDLE1BQWxCLEdBQTJCLENBQS9CLEVBQWtDO0FBQ2hDLG9CQUFZLEdBQUcsaUJBQWlCLENBQUMsQ0FBRCxDQUFoQztBQUNBLHNCQUFjLEdBQUcsSUFBakI7QUFDRDtBQUNGO0FBQ0Y7O0FBRUQsTUFBSSxXQUFXLEdBQUcsRUFBbEI7O0FBRUEsTUFBSSxZQUFKLEVBQWtCO0FBQ2hCLFFBQUksWUFBSixFQUFrQjtBQUNoQjtBQUNBLFVBQUksZUFBZSxDQUFDLEtBQWhCLElBQXlCLE9BQXpCLElBQW9DLGVBQWUsQ0FBQyxHQUFoQixJQUF1QixPQUEvRCxFQUF3RTtBQUN0RSxtQkFBVyxJQUFJLGdDQUFmO0FBQ0QsT0FGRCxNQUVPLElBQ0wsWUFBWSxDQUFDLEtBQWIsSUFBc0IsT0FBdEIsSUFDQSxlQUFlLENBQUMsR0FBaEIsSUFBdUIsT0FGbEIsRUFHTDtBQUNBLG1CQUFXLElBQ1QsMERBREY7QUFFQSxtQkFBVyxHQUFHLFdBQVcsQ0FBQyxPQUFaLENBQ1osZUFEWSxFQUVaO0FBQ0EsdUJBQWUsQ0FBQyxHQUhKLENBQWQ7QUFLRCxPQVhNLE1BV0E7QUFDTCxtQkFBVyxJQUFJLGlEQUFmO0FBQ0EsbUJBQVcsR0FBRyxXQUFXLENBQUMsT0FBWixDQUNaLGVBRFksRUFFWjtBQUNBLHVCQUFlLENBQUMsR0FISixDQUFkO0FBS0Q7QUFDRixLQXZCRCxNQXVCTztBQUNMLFVBQUksY0FBSixFQUFvQjtBQUNsQixtQkFBVyxJQUNULDJEQURGO0FBRUEsbUJBQVcsR0FBRyxXQUFXLENBQUMsT0FBWixDQUNaLGVBRFksRUFFWjtBQUNBLG9CQUFZLENBQUMsS0FIRCxDQUFkO0FBS0QsT0FSRCxNQVFPO0FBQ0wsbUJBQVcsSUFBSSxrREFBZjtBQUNBLG1CQUFXLEdBQUcsV0FBVyxDQUFDLE9BQVosQ0FDWixlQURZLEVBRVo7QUFDQSxvQkFBWSxDQUFDLEtBSEQsQ0FBZDtBQUtEO0FBQ0Y7QUFDRjs7QUFFRCxTQUFPLFdBQVA7QUFDRDs7QUFFRCxTQUFTLFVBQVQsQ0FBb0IsSUFBcEIsRUFBd0I7QUFDdEIsTUFBTSxRQUFRLEdBQUcsSUFBSSxJQUFKLENBQVMscUJBQXFCLElBQTlCLENBQWpCO0FBQ0EsTUFBTSxZQUFZLEdBQUcsT0FBckI7QUFDQSxTQUFPLFFBQVEsQ0FBQyxrQkFBVCxDQUE0QixZQUFZLENBQUMsT0FBYixDQUFxQixHQUFyQixFQUEwQixHQUExQixDQUE1QixFQUE0RDtBQUNqRSxRQUFJLEVBQUUsU0FEMkQ7QUFFakUsVUFBTSxFQUFFO0FBRnlELEdBQTVELENBQVA7QUFJRDs7QUFFRCxTQUFTLGtCQUFULENBQTRCLFVBQTVCLEVBQThDO0FBQzVDLE1BQU0sS0FBSyxHQUFHLFVBQVUsQ0FBQyxLQUFYLENBQWlCLEdBQWpCLENBQWQ7QUFDQSxNQUFNLEtBQUssR0FBRyxRQUFRLENBQUMsS0FBSyxDQUFDLENBQUQsQ0FBTCxDQUFTLE9BQVQsQ0FBaUIsU0FBakIsRUFBNEIsRUFBNUIsQ0FBRCxFQUFrQyxFQUFsQyxDQUF0QjtBQUNBLE1BQU0sT0FBTyxHQUFHLFFBQVEsQ0FBQyxLQUFLLENBQUMsQ0FBRCxDQUFMLENBQVMsT0FBVCxDQUFpQixTQUFqQixFQUE0QixFQUE1QixDQUFELEVBQWtDLEVBQWxDLENBQXhCO0FBQ0EsU0FBTyxLQUFLLEdBQUcsT0FBTyxHQUFHLEVBQXpCO0FBQ0Q7O0FBRUQsU0FBUyx3QkFBVCxDQUFrQyxzQkFBbEMsRUFBZ0U7QUFDOUQsTUFBTSxHQUFHLEdBQUcsSUFBSSxJQUFKLEVBQVo7QUFDQSxNQUFJLFNBQVMsR0FBRyxDQUFoQjs7QUFDQSxNQUFJLHNCQUFKLEVBQTRCO0FBQzFCLGFBQVMsR0FBRyxzQkFBc0IsR0FBRyxJQUFyQztBQUNEOztBQUNELE1BQUksU0FBUyxLQUFLLENBQWxCLEVBQXFCO0FBQ25CLFFBQU0sY0FBYyxHQUFHLEdBQUcsQ0FBQyxpQkFBSixLQUEwQixFQUExQixHQUErQixJQUF0RDtBQUNBLFdBQU8sSUFBSSxJQUFKLENBQVMsR0FBRyxDQUFDLE9BQUosS0FBZ0IsU0FBaEIsR0FBNEIsY0FBckMsQ0FBUDtBQUNEOztBQUNELFNBQU8sR0FBUDtBQUNELEMsQ0FFRDs7O0FBQ00sU0FBVSxzQkFBVixDQUFpQyxVQUFqQyxFQUEyQztBQUMvQyxNQUFJLENBQUMsVUFBTCxFQUFpQjtBQUNmLFdBQU8sQ0FBUDtBQUNEOztBQUNELE1BQU0sS0FBSyxHQUFHLFVBQVUsQ0FBQyxLQUFYLENBQWlCLEdBQWpCLENBQWQ7QUFDQSxNQUFNLEtBQUssR0FBRyxRQUFRLENBQUMsS0FBSyxDQUFDLENBQUQsQ0FBTCxDQUFTLE9BQVQsQ0FBaUIsU0FBakIsRUFBNEIsRUFBNUIsQ0FBRCxFQUFrQyxFQUFsQyxDQUF0QjtBQUNBLE1BQU0sT0FBTyxHQUFHLFFBQVEsQ0FBQyxLQUFLLENBQUMsQ0FBRCxDQUFMLENBQVMsT0FBVCxDQUFpQixTQUFqQixFQUE0QixFQUE1QixDQUFELEVBQWtDLEVBQWxDLENBQXhCOztBQUNBLE1BQUksS0FBSyxHQUFHLENBQVosRUFBZTtBQUNiLFdBQU8sRUFBRSxJQUFJLENBQUMsR0FBTCxDQUFTLEtBQVQsSUFBa0IsT0FBTyxHQUFHLEVBQTlCLElBQW9DLEVBQXBDLEdBQXlDLEVBQWhEO0FBQ0Q7O0FBQ0QsU0FBTyxDQUFDLEtBQUssR0FBRyxPQUFPLEdBQUcsRUFBbkIsSUFBeUIsRUFBekIsR0FBOEIsRUFBckM7QUFDRDs7QUFFRCxTQUFTLGlCQUFULENBQTJCLElBQTNCLEVBQWlDLFNBQWpDLEVBQTBDO0FBQ3hDLE1BQU0sR0FBRyxHQUFHLElBQUksQ0FBQyxPQUFMLEVBQVo7QUFDQSxNQUFNLEtBQUssR0FBRyxJQUFJLENBQUMsUUFBTCxLQUFrQixDQUFoQztBQUNBLE1BQU0sSUFBSSxHQUFHLElBQUksQ0FBQyxXQUFMLEVBQWI7QUFFQSxNQUFNLElBQUksR0FBRyxDQUNYLFFBRFcsRUFFWCxRQUZXLEVBR1gsU0FIVyxFQUlYLFdBSlcsRUFLWCxVQUxXLEVBTVgsUUFOVyxFQU9YLFVBUFcsQ0FBYjtBQVVBLE1BQU0sVUFBVSxHQUNkLElBQUksR0FDSixHQURBLElBRUMsS0FBSyxHQUFHLEVBQVIsR0FBYSxNQUFNLEtBQW5CLEdBQTJCLEtBRjVCLElBR0EsR0FIQSxJQUlDLEdBQUcsR0FBRyxFQUFOLEdBQVcsTUFBTSxHQUFqQixHQUF1QixHQUp4QixDQURGO0FBTUEsTUFBTSxlQUFlLEdBQUcsSUFBSSxDQUFDLElBQUksQ0FBQyxNQUFMLEVBQUQsQ0FBNUIsQ0FyQndDLENBdUJ4Qzs7QUFDQSxNQUFJLFNBQVMsQ0FBQyxZQUFkLEVBQTRCO0FBQzFCLFNBQUssSUFBSSxDQUFDLEdBQUcsQ0FBYixFQUFnQixDQUFDLEdBQUcsU0FBUyxDQUFDLFlBQVYsQ0FBdUIsTUFBM0MsRUFBbUQsQ0FBQyxFQUFwRCxFQUF3RDtBQUN0RCxVQUFNLE9BQU8sR0FBRyxTQUFTLENBQUMsWUFBVixDQUF1QixDQUF2QixDQUFoQjs7QUFDQSxVQUFJLE9BQU8sQ0FBQyxJQUFSLElBQWdCLFVBQXBCLEVBQWdDO0FBQzlCLFlBQUksT0FBTyxDQUFDLGFBQVosRUFBMkI7QUFDekIsaUJBQU8sT0FBTyxDQUFDLGFBQWY7QUFDRCxTQUZELE1BRU8sSUFBSSxPQUFPLENBQUMsUUFBUixLQUFxQixJQUF6QixFQUErQjtBQUNwQyxpQkFBTyxJQUFQLENBRG9DLENBQ3ZCO0FBQ2Q7QUFDRjtBQUNGO0FBQ0YsR0FuQ3VDLENBcUN4Qzs7O0FBQ0EsTUFBSSxTQUFTLENBQUMsZUFBRCxDQUFULElBQThCLFNBQVMsQ0FBQyxlQUFELENBQVQsQ0FBMkIsYUFBN0QsRUFBNEU7QUFDMUUsV0FBTyxTQUFTLENBQUMsZUFBRCxDQUFULENBQTJCLGFBQWxDO0FBQ0QsR0FGRCxNQUVPO0FBQ0wsV0FBTyxJQUFQO0FBQ0Q7QUFDRixDOzs7Ozs7Ozs7O0FDMU5EO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7OztBQUdBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxxRTs7Ozs7O1VDakNBO1VBQ0E7O1VBRUE7VUFDQTtVQUNBO1VBQ0E7VUFDQTtVQUNBO1VBQ0E7VUFDQTtVQUNBO1VBQ0E7VUFDQTtVQUNBO1VBQ0E7O1VBRUE7VUFDQTs7VUFFQTtVQUNBO1VBQ0E7Ozs7O1dDdEJBO1dBQ0E7V0FDQTtXQUNBO1dBQ0Esd0NBQXdDLHlDQUF5QztXQUNqRjtXQUNBO1dBQ0EsRTs7Ozs7V0NQQTtXQUNBO1dBQ0E7V0FDQTtXQUNBLEVBQUU7V0FDRjtXQUNBO1dBQ0EsQ0FBQyxJOzs7OztXQ1BELHdGOzs7OztXQ0FBO1dBQ0E7V0FDQTtXQUNBLHNEQUFzRCxrQkFBa0I7V0FDeEU7V0FDQSwrQ0FBK0MsY0FBYztXQUM3RCxFOzs7OztXQ05BO1dBQ0E7V0FDQTtXQUNBO1dBQ0E7V0FDQTtXQUNBO1dBQ0E7V0FDQTtXQUNBO1dBQ0E7V0FDQTtXQUNBO1dBQ0E7V0FDQTtXQUNBLGtDOzs7Ozs7Ozs7Ozs7OztBQ2ZBO0FBRUE7O0FBTUEsU0FBU0MsU0FBVCxDQUFtQkMsQ0FBbkIsRUFBc0I7QUFDbEIsTUFBSUMsTUFBTSxHQUFHLEVBQWI7QUFDQUQsR0FBQyxDQUFDRSxJQUFGLEdBQVNDLEdBQVQsQ0FBYSxVQUFDQyxJQUFELEVBQU9DLEtBQVAsRUFBaUI7QUFBRUosVUFBTSxDQUFDRyxJQUFJLENBQUNFLE9BQUwsQ0FBYSxJQUFiLEVBQW1CLEVBQW5CLENBQUQsQ0FBTixHQUFpQ04sQ0FBQyxDQUFDSSxJQUFELENBQWxDO0FBQTJDLEdBQTNFO0FBQ0EsU0FBT0gsTUFBUDtBQUNEOztBQUVELElBQU1BLE1BQU0sR0FBR0YsU0FBUyxDQUFDUSxxRUFBRCxDQUF4QixDLENBQ0Esc0UiLCJmaWxlIjoibWFpbi5qcyIsInNvdXJjZXNDb250ZW50IjpbImV4cG9ydCBkZWZhdWx0IF9fd2VicGFja19wdWJsaWNfcGF0aF9fICsgXCJpbWFnZXMvYWRkcmVzcy5zdmdcIjsiLCJleHBvcnQgZGVmYXVsdCBfX3dlYnBhY2tfcHVibGljX3BhdGhfXyArIFwiaW1hZ2VzL2Jhbm5lci53ZWJwXCI7IiwiZXhwb3J0IGRlZmF1bHQgX193ZWJwYWNrX3B1YmxpY19wYXRoX18gKyBcImltYWdlcy9sZWZ0LWFycm93LnN2Z1wiOyIsImV4cG9ydCBkZWZhdWx0IF9fd2VicGFja19wdWJsaWNfcGF0aF9fICsgXCJpbWFnZXMvbG9jYXRpb24uanBnXCI7IiwiZXhwb3J0IGRlZmF1bHQgX193ZWJwYWNrX3B1YmxpY19wYXRoX18gKyBcImltYWdlcy9sb2dvLnBuZ1wiOyIsImV4cG9ydCBkZWZhdWx0IF9fd2VicGFja19wdWJsaWNfcGF0aF9fICsgXCJpbWFnZXMvbHV4dXJ5c3RvcmUuanBlZ1wiOyIsImV4cG9ydCBkZWZhdWx0IF9fd2VicGFja19wdWJsaWNfcGF0aF9fICsgXCJpbWFnZXMvcGhvbmUuc3ZnXCI7IiwiZXhwb3J0IGRlZmF1bHQgX193ZWJwYWNrX3B1YmxpY19wYXRoX18gKyBcImltYWdlcy9yaWdodC1hcnJvdy5zdmdcIjsiLCJleHBvcnQgZGVmYXVsdCBfX3dlYnBhY2tfcHVibGljX3BhdGhfXyArIFwiaW1hZ2VzL3NsaWRlLndlYnBcIjsiLCJleHBvcnQgZGVmYXVsdCBfX3dlYnBhY2tfcHVibGljX3BhdGhfXyArIFwiaW1hZ2VzL3RpbWUuc3ZnXCI7IiwiZXhwb3J0IGRlZmF1bHQgX193ZWJwYWNrX3B1YmxpY19wYXRoX18gKyBcImltYWdlcy95ZXh0LWZhdmljb24ucG5nXCI7IiwiZXhwb3J0IGRlZmF1bHQgX193ZWJwYWNrX3B1YmxpY19wYXRoX18gKyBcImltYWdlcy95ZXh0LWxvZ28uc3ZnXCI7IiwiLy8gZXh0cmFjdGVkIGJ5IG1pbmktY3NzLWV4dHJhY3QtcGx1Z2luXG5leHBvcnQge307IiwiLy8gRm9ybWF0cyBob3VycyBmdW5jdGlvblxyXG4vLyBPcGVuIMK3IENsb3NlcyBhdCA1cG1cclxuLy8gQ2xvc2VkIMK3IE9wZW4gYXQgNmFtXHJcbmV4cG9ydCBmdW5jdGlvbiBmb3JtYXRPcGVuTm93U3RyaW5nKGhvdXJzRGF0YSwgdXRjT2Zmc2V0KSB7XHJcbiAgY29uc3Qgbm93ID0gZ2V0WWV4dFRpbWVXaXRoVXRjT2Zmc2V0KHV0Y09mZnNldCk7XHJcblxyXG4gIGNvbnN0IHRvbW9ycm93ID0gbmV3IERhdGUobm93LmdldFRpbWUoKSArIDYwICogNjAgKiAyNCAqIDEwMDApO1xyXG4gIGNvbnN0IHllc3RlcmRheSA9IG5ldyBEYXRlKG5vdy5nZXRUaW1lKCkgLSA2MCAqIDYwICogMjQgKiAxMDAwKTtcclxuICBjb25zdCBub3dUaW1lTnVtYmVyID0gbm93LmdldEhvdXJzKCkgKyBub3cuZ2V0TWludXRlcygpIC8gNjA7XHJcblxyXG4gIGNvbnN0IGludGVydmFsc1RvZGF5ID0gZ2V0SW50ZXJ2YWxPbkRhdGUobm93LCBob3Vyc0RhdGEpO1xyXG4gIGNvbnN0IGludGVydmFsc1RvbW9ycm93ID0gZ2V0SW50ZXJ2YWxPbkRhdGUodG9tb3Jyb3csIGhvdXJzRGF0YSk7XHJcbiAgY29uc3QgaW50ZXJ2YWxzWWVzdGVyZGF5ID0gZ2V0SW50ZXJ2YWxPbkRhdGUoeWVzdGVyZGF5LCBob3Vyc0RhdGEpO1xyXG4gIGxldCBvcGVuUmlnaHROb3cgPSBmYWxzZTtcclxuICBsZXQgY3VycmVudEludGVydmFsID0gbnVsbDtcclxuICBsZXQgbmV4dEludGVydmFsID0gbnVsbDtcclxuXHJcbiAgaWYgKGludGVydmFsc1llc3RlcmRheSkge1xyXG4gICAgZm9yIChsZXQgaSA9IDA7IGkgPCBpbnRlcnZhbHNZZXN0ZXJkYXkubGVuZ3RoOyBpKyspIHtcclxuICAgICAgY29uc3QgaW50ZXJ2YWwgPSBpbnRlcnZhbHNZZXN0ZXJkYXlbaV07XHJcbiAgICAgIGNvbnN0IHN0YXJ0SW50ZXJ2YWxOdW1iZXIgPSB0aW1lU3RyaW5nVG9OdW1iZXIoaW50ZXJ2YWwuc3RhcnQpO1xyXG4gICAgICBjb25zdCBlbmRJbnRlcnZhbE51bWJlciA9IHRpbWVTdHJpbmdUb051bWJlcihpbnRlcnZhbC5lbmQpO1xyXG5cclxuICAgICAgLy8gSWYgZW5kIG92ZXJmbG93cyB0byB0aGUgbmV4dCBkYXkgKGkuZS4gdG9kYXkpLlxyXG4gICAgICBpZiAoZW5kSW50ZXJ2YWxOdW1iZXIgPCBzdGFydEludGVydmFsTnVtYmVyKSB7XHJcbiAgICAgICAgaWYgKG5vd1RpbWVOdW1iZXIgPCBlbmRJbnRlcnZhbE51bWJlcikge1xyXG4gICAgICAgICAgY3VycmVudEludGVydmFsID0gaW50ZXJ2YWw7XHJcbiAgICAgICAgICBvcGVuUmlnaHROb3cgPSB0cnVlO1xyXG4gICAgICAgIH1cclxuICAgICAgfVxyXG4gICAgfVxyXG4gIH1cclxuXHJcbiAgLy8gQXNzdW1lcyBubyBvdmVybGFwcGluZyBpbnRlcnZhbHNcclxuICBpZiAoaW50ZXJ2YWxzVG9kYXkpIHtcclxuICAgIGZvciAobGV0IGkgPSAwOyBpIDwgaW50ZXJ2YWxzVG9kYXkubGVuZ3RoOyBpKyspIHtcclxuICAgICAgY29uc3QgaW50ZXJ2YWwgPSBpbnRlcnZhbHNUb2RheVtpXTtcclxuICAgICAgY29uc3Qgc3RhcnRJbnRlcnZhbE51bWJlciA9IHRpbWVTdHJpbmdUb051bWJlcihpbnRlcnZhbC5zdGFydCk7XHJcbiAgICAgIGNvbnN0IGVuZEludGVydmFsTnVtYmVyID0gdGltZVN0cmluZ1RvTnVtYmVyKGludGVydmFsLmVuZCk7XHJcblxyXG4gICAgICAvLyBJZiBjdXJyZW50IHRpbWUgZG9lc24ndCBiZWxvbmcgdG8gb25lIG9mIHllc3RlcmRheXMgaW50ZXJ2YWwuXHJcbiAgICAgIGlmIChjdXJyZW50SW50ZXJ2YWwgPT0gbnVsbCkge1xyXG4gICAgICAgIGlmIChlbmRJbnRlcnZhbE51bWJlciA8IHN0YXJ0SW50ZXJ2YWxOdW1iZXIpIHtcclxuICAgICAgICAgIGlmIChub3dUaW1lTnVtYmVyID49IHN0YXJ0SW50ZXJ2YWxOdW1iZXIpIHtcclxuICAgICAgICAgICAgY3VycmVudEludGVydmFsID0gaW50ZXJ2YWw7XHJcbiAgICAgICAgICAgIG9wZW5SaWdodE5vdyA9IHRydWU7XHJcbiAgICAgICAgICB9XHJcbiAgICAgICAgfSBlbHNlIGlmIChcclxuICAgICAgICAgIG5vd1RpbWVOdW1iZXIgPj0gc3RhcnRJbnRlcnZhbE51bWJlciAmJlxyXG4gICAgICAgICAgbm93VGltZU51bWJlciA8IGVuZEludGVydmFsTnVtYmVyXHJcbiAgICAgICAgKSB7XHJcbiAgICAgICAgICBjdXJyZW50SW50ZXJ2YWwgPSBpbnRlcnZhbDtcclxuICAgICAgICAgIG9wZW5SaWdodE5vdyA9IHRydWU7XHJcbiAgICAgICAgfVxyXG4gICAgICB9XHJcblxyXG4gICAgICBpZiAobmV4dEludGVydmFsID09IG51bGwpIHtcclxuICAgICAgICBpZiAoc3RhcnRJbnRlcnZhbE51bWJlciA+IG5vd1RpbWVOdW1iZXIpIHtcclxuICAgICAgICAgIG5leHRJbnRlcnZhbCA9IGludGVydmFsO1xyXG4gICAgICAgIH1cclxuICAgICAgfSBlbHNlIHtcclxuICAgICAgICBpZiAoXHJcbiAgICAgICAgICBzdGFydEludGVydmFsTnVtYmVyID4gbm93VGltZU51bWJlciAmJlxyXG4gICAgICAgICAgc3RhcnRJbnRlcnZhbE51bWJlciA8IHRpbWVTdHJpbmdUb051bWJlcihuZXh0SW50ZXJ2YWwuc3RhcnQpXHJcbiAgICAgICAgKSB7XHJcbiAgICAgICAgICBuZXh0SW50ZXJ2YWwgPSBpbnRlcnZhbDtcclxuICAgICAgICB9XHJcbiAgICAgIH1cclxuICAgIH1cclxuICB9XHJcblxyXG4gIGxldCBuZXh0SXNUb21vcnJvdyA9IGZhbHNlO1xyXG5cclxuICAvLyBJZiBubyBtb3JlIGludGVydmFscyBpbiB0aGUgZGF5XHJcbiAgaWYgKG5leHRJbnRlcnZhbCA9PSBudWxsKSB7XHJcbiAgICBpZiAoaW50ZXJ2YWxzVG9tb3Jyb3cpIHtcclxuICAgICAgaWYgKGludGVydmFsc1RvbW9ycm93Lmxlbmd0aCA+IDApIHtcclxuICAgICAgICBuZXh0SW50ZXJ2YWwgPSBpbnRlcnZhbHNUb21vcnJvd1swXTtcclxuICAgICAgICBuZXh0SXNUb21vcnJvdyA9IHRydWU7XHJcbiAgICAgIH1cclxuICAgIH1cclxuICB9XHJcblxyXG4gIGxldCBob3Vyc1N0cmluZyA9IFwiXCI7XHJcblxyXG4gIGlmIChuZXh0SW50ZXJ2YWwpIHtcclxuICAgIGlmIChvcGVuUmlnaHROb3cpIHtcclxuICAgICAgLy8gQ2hlY2sgZmlyc3QgZm9yIGEgMjQtaG91ciBpbnRlcnZhbCwgdGhlbiBjaGVjayBmb3Igb3BlbiBwYXN0IG1pZG5pZ2h0XHJcbiAgICAgIGlmIChjdXJyZW50SW50ZXJ2YWwuc3RhcnQgPT0gXCIwMDowMFwiICYmIGN1cnJlbnRJbnRlcnZhbC5lbmQgPT0gXCIyMzo1OVwiKSB7XHJcbiAgICAgICAgaG91cnNTdHJpbmcgKz0gXCI8c3Ryb25nPk9wZW4gMjQgaG91cnM8L3N0cm9uZz5cIjtcclxuICAgICAgfSBlbHNlIGlmIChcclxuICAgICAgICBuZXh0SW50ZXJ2YWwuc3RhcnQgPT0gXCIwMDowMFwiICYmXHJcbiAgICAgICAgY3VycmVudEludGVydmFsLmVuZCA9PSBcIjIzOjU5XCJcclxuICAgICAgKSB7XHJcbiAgICAgICAgaG91cnNTdHJpbmcgKz1cclxuICAgICAgICAgIFwiPHN0cm9uZz5PcGVuPC9zdHJvbmc+IMK3IENsb3NlcyBhdCBbY2xvc2luZ1RpbWVdIHRvbW9ycm93XCI7XHJcbiAgICAgICAgaG91cnNTdHJpbmcgPSBob3Vyc1N0cmluZy5yZXBsYWNlKFxyXG4gICAgICAgICAgXCJbY2xvc2luZ1RpbWVdXCIsXHJcbiAgICAgICAgICAvLyBmb3JtYXRUaW1lKGN1cnJlbnRJbnRlcnZhbC5lbmQpXHJcbiAgICAgICAgICBjdXJyZW50SW50ZXJ2YWwuZW5kXHJcbiAgICAgICAgKTtcclxuICAgICAgfSBlbHNlIHtcclxuICAgICAgICBob3Vyc1N0cmluZyArPSBcIjxzdHJvbmc+T3Blbjwvc3Ryb25nPiDCtyBDbG9zZXMgYXQgW2Nsb3NpbmdUaW1lXVwiO1xyXG4gICAgICAgIGhvdXJzU3RyaW5nID0gaG91cnNTdHJpbmcucmVwbGFjZShcclxuICAgICAgICAgIFwiW2Nsb3NpbmdUaW1lXVwiLFxyXG4gICAgICAgICAgLy8gZm9ybWF0VGltZShjdXJyZW50SW50ZXJ2YWwuZW5kKVxyXG4gICAgICAgICAgY3VycmVudEludGVydmFsLmVuZFxyXG4gICAgICAgICk7XHJcbiAgICAgIH1cclxuICAgIH0gZWxzZSB7XHJcbiAgICAgIGlmIChuZXh0SXNUb21vcnJvdykge1xyXG4gICAgICAgIGhvdXJzU3RyaW5nICs9XHJcbiAgICAgICAgICBcIjxzdHJvbmc+Q2xvc2VkPC9zdHJvbmc+IMK3IE9wZW5zIGF0IFtvcGVuaW5nVGltZV0gdG9tb3Jyb3dcIjtcclxuICAgICAgICBob3Vyc1N0cmluZyA9IGhvdXJzU3RyaW5nLnJlcGxhY2UoXHJcbiAgICAgICAgICBcIltvcGVuaW5nVGltZV1cIixcclxuICAgICAgICAgIC8vIGZvcm1hdFRpbWUobmV4dEludGVydmFsLnN0YXJ0KVxyXG4gICAgICAgICAgbmV4dEludGVydmFsLnN0YXJ0XHJcbiAgICAgICAgKTtcclxuICAgICAgfSBlbHNlIHtcclxuICAgICAgICBob3Vyc1N0cmluZyArPSBcIjxzdHJvbmc+Q2xvc2VkPC9zdHJvbmc+IMK3IE9wZW5zIGF0IFtvcGVuaW5nVGltZV1cIjtcclxuICAgICAgICBob3Vyc1N0cmluZyA9IGhvdXJzU3RyaW5nLnJlcGxhY2UoXHJcbiAgICAgICAgICBcIltvcGVuaW5nVGltZV1cIixcclxuICAgICAgICAgIC8vIGZvcm1hdFRpbWUobmV4dEludGVydmFsLnN0YXJ0KVxyXG4gICAgICAgICAgbmV4dEludGVydmFsLnN0YXJ0XHJcbiAgICAgICAgKTtcclxuICAgICAgfVxyXG4gICAgfVxyXG4gIH1cclxuXHJcbiAgcmV0dXJuIGhvdXJzU3RyaW5nO1xyXG59XHJcblxyXG5mdW5jdGlvbiBmb3JtYXRUaW1lKHRpbWUpIHtcclxuICBjb25zdCB0ZW1wRGF0ZSA9IG5ldyBEYXRlKFwiSmFudWFyeSAxLCAyMDIwIFwiICsgdGltZSk7XHJcbiAgY29uc3QgbG9jYWxlU3RyaW5nID0gXCJlbi1VU1wiO1xyXG4gIHJldHVybiB0ZW1wRGF0ZS50b0xvY2FsZVRpbWVTdHJpbmcobG9jYWxlU3RyaW5nLnJlcGxhY2UoXCJfXCIsIFwiLVwiKSwge1xyXG4gICAgaG91cjogXCJudW1lcmljXCIsXHJcbiAgICBtaW51dGU6IFwibnVtZXJpY1wiLFxyXG4gIH0pO1xyXG59XHJcblxyXG5mdW5jdGlvbiB0aW1lU3RyaW5nVG9OdW1iZXIodGltZVN0cmluZzogc3RyaW5nKTogbnVtYmVyIHtcclxuICBjb25zdCBwYXJ0cyA9IHRpbWVTdHJpbmcuc3BsaXQoXCI6XCIpO1xyXG4gIGNvbnN0IGhvdXJzID0gcGFyc2VJbnQocGFydHNbMF0ucmVwbGFjZSgvXFx1MjAwRS9nLCBcIlwiKSwgMTApO1xyXG4gIGNvbnN0IG1pbnV0ZXMgPSBwYXJzZUludChwYXJ0c1sxXS5yZXBsYWNlKC9cXHUyMDBFL2csIFwiXCIpLCAxMCk7XHJcbiAgcmV0dXJuIGhvdXJzICsgbWludXRlcyAvIDYwO1xyXG59XHJcblxyXG5mdW5jdGlvbiBnZXRZZXh0VGltZVdpdGhVdGNPZmZzZXQoZW50aXR5VXRjT2Zmc2V0U2Vjb25kczogbnVtYmVyKTogRGF0ZSB7XHJcbiAgY29uc3Qgbm93ID0gbmV3IERhdGUoKTtcclxuICBsZXQgdXRjT2Zmc2V0ID0gMDtcclxuICBpZiAoZW50aXR5VXRjT2Zmc2V0U2Vjb25kcykge1xyXG4gICAgdXRjT2Zmc2V0ID0gZW50aXR5VXRjT2Zmc2V0U2Vjb25kcyAqIDEwMDA7XHJcbiAgfVxyXG4gIGlmICh1dGNPZmZzZXQgIT09IDApIHtcclxuICAgIGNvbnN0IGxvY2FsVXRjT2Zmc2V0ID0gbm93LmdldFRpbWV6b25lT2Zmc2V0KCkgKiA2MCAqIDEwMDA7XHJcbiAgICByZXR1cm4gbmV3IERhdGUobm93LnZhbHVlT2YoKSArIHV0Y09mZnNldCArIGxvY2FsVXRjT2Zmc2V0KTtcclxuICB9XHJcbiAgcmV0dXJuIG5vdztcclxufVxyXG5cclxuLy8gUGFyc2VzIGFuIG9mZnNldCBmb3JtYXR0ZWQgbGlrZSB7Ky8tfXswNH06ezAwfVxyXG5leHBvcnQgZnVuY3Rpb24gcGFyc2VUaW1lWm9uZVV0Y09mZnNldCh0aW1lU3RyaW5nKSB7XHJcbiAgaWYgKCF0aW1lU3RyaW5nKSB7XHJcbiAgICByZXR1cm4gMDtcclxuICB9XHJcbiAgY29uc3QgcGFydHMgPSB0aW1lU3RyaW5nLnNwbGl0KFwiOlwiKTtcclxuICBjb25zdCBob3VycyA9IHBhcnNlSW50KHBhcnRzWzBdLnJlcGxhY2UoL1xcdTIwMEUvZywgXCJcIiksIDEwKTtcclxuICBjb25zdCBtaW51dGVzID0gcGFyc2VJbnQocGFydHNbMV0ucmVwbGFjZSgvXFx1MjAwRS9nLCBcIlwiKSwgMTApO1xyXG4gIGlmIChob3VycyA8IDApIHtcclxuICAgIHJldHVybiAtKE1hdGguYWJzKGhvdXJzKSArIG1pbnV0ZXMgLyA2MCkgKiA2MCAqIDYwO1xyXG4gIH1cclxuICByZXR1cm4gKGhvdXJzICsgbWludXRlcyAvIDYwKSAqIDYwICogNjA7XHJcbn1cclxuXHJcbmZ1bmN0aW9uIGdldEludGVydmFsT25EYXRlKGRhdGUsIGhvdXJzRGF0YSkge1xyXG4gIGNvbnN0IGRheSA9IGRhdGUuZ2V0RGF0ZSgpO1xyXG4gIGNvbnN0IG1vbnRoID0gZGF0ZS5nZXRNb250aCgpICsgMTtcclxuICBjb25zdCB5ZWFyID0gZGF0ZS5nZXRGdWxsWWVhcigpO1xyXG5cclxuICBjb25zdCBkYXlzID0gW1xyXG4gICAgXCJzdW5kYXlcIixcclxuICAgIFwibW9uZGF5XCIsXHJcbiAgICBcInR1ZXNkYXlcIixcclxuICAgIFwid2VkbmVzZGF5XCIsXHJcbiAgICBcInRodXJzZGF5XCIsXHJcbiAgICBcImZyaWRheVwiLFxyXG4gICAgXCJzYXR1cmRheVwiLFxyXG4gIF07XHJcblxyXG4gIGNvbnN0IGRhdGVTdHJpbmcgPVxyXG4gICAgeWVhciArXHJcbiAgICBcIi1cIiArXHJcbiAgICAobW9udGggPCAxMCA/IFwiMFwiICsgbW9udGggOiBtb250aCkgK1xyXG4gICAgXCItXCIgK1xyXG4gICAgKGRheSA8IDEwID8gXCIwXCIgKyBkYXkgOiBkYXkpO1xyXG4gIGNvbnN0IGRheU9mV2Vla1N0cmluZyA9IGRheXNbZGF0ZS5nZXREYXkoKV07XHJcblxyXG4gIC8vIENoZWNrIGZvciBob2xpZGF5XHJcbiAgaWYgKGhvdXJzRGF0YS5ob2xpZGF5SG91cnMpIHtcclxuICAgIGZvciAobGV0IGkgPSAwOyBpIDwgaG91cnNEYXRhLmhvbGlkYXlIb3Vycy5sZW5ndGg7IGkrKykge1xyXG4gICAgICBjb25zdCBob2xpZGF5ID0gaG91cnNEYXRhLmhvbGlkYXlIb3Vyc1tpXTtcclxuICAgICAgaWYgKGhvbGlkYXkuZGF0ZSA9PSBkYXRlU3RyaW5nKSB7XHJcbiAgICAgICAgaWYgKGhvbGlkYXkub3BlbkludGVydmFscykge1xyXG4gICAgICAgICAgcmV0dXJuIGhvbGlkYXkub3BlbkludGVydmFscztcclxuICAgICAgICB9IGVsc2UgaWYgKGhvbGlkYXkuaXNDbG9zZWQgPT09IHRydWUpIHtcclxuICAgICAgICAgIHJldHVybiBudWxsOyAvLyBPbiBob2xpZGF5IGJ1dCBjbG9zZWRcclxuICAgICAgICB9XHJcbiAgICAgIH1cclxuICAgIH1cclxuICB9XHJcblxyXG4gIC8vIE5vdCBvbiBob2xpZGF5XHJcbiAgaWYgKGhvdXJzRGF0YVtkYXlPZldlZWtTdHJpbmddICYmIGhvdXJzRGF0YVtkYXlPZldlZWtTdHJpbmddLm9wZW5JbnRlcnZhbHMpIHtcclxuICAgIHJldHVybiBob3Vyc0RhdGFbZGF5T2ZXZWVrU3RyaW5nXS5vcGVuSW50ZXJ2YWxzO1xyXG4gIH0gZWxzZSB7XHJcbiAgICByZXR1cm4gbnVsbDtcclxuICB9XHJcbn1cclxuIiwidmFyIG1hcCA9IHtcblx0XCIuL2FkZHJlc3Muc3ZnXCI6IFwiLi9zcmMvaW1hZ2VzL2FkZHJlc3Muc3ZnXCIsXG5cdFwiLi9iYW5uZXIud2VicFwiOiBcIi4vc3JjL2ltYWdlcy9iYW5uZXIud2VicFwiLFxuXHRcIi4vbGVmdC1hcnJvdy5zdmdcIjogXCIuL3NyYy9pbWFnZXMvbGVmdC1hcnJvdy5zdmdcIixcblx0XCIuL2xvY2F0aW9uLmpwZ1wiOiBcIi4vc3JjL2ltYWdlcy9sb2NhdGlvbi5qcGdcIixcblx0XCIuL2xvZ28ucG5nXCI6IFwiLi9zcmMvaW1hZ2VzL2xvZ28ucG5nXCIsXG5cdFwiLi9sdXh1cnlzdG9yZS5qcGVnXCI6IFwiLi9zcmMvaW1hZ2VzL2x1eHVyeXN0b3JlLmpwZWdcIixcblx0XCIuL3Bob25lLnN2Z1wiOiBcIi4vc3JjL2ltYWdlcy9waG9uZS5zdmdcIixcblx0XCIuL3JpZ2h0LWFycm93LnN2Z1wiOiBcIi4vc3JjL2ltYWdlcy9yaWdodC1hcnJvdy5zdmdcIixcblx0XCIuL3NsaWRlLndlYnBcIjogXCIuL3NyYy9pbWFnZXMvc2xpZGUud2VicFwiLFxuXHRcIi4vdGltZS5zdmdcIjogXCIuL3NyYy9pbWFnZXMvdGltZS5zdmdcIixcblx0XCIuL3lleHQtZmF2aWNvbi5wbmdcIjogXCIuL3NyYy9pbWFnZXMveWV4dC1mYXZpY29uLnBuZ1wiLFxuXHRcIi4veWV4dC1sb2dvLnN2Z1wiOiBcIi4vc3JjL2ltYWdlcy95ZXh0LWxvZ28uc3ZnXCJcbn07XG5cblxuZnVuY3Rpb24gd2VicGFja0NvbnRleHQocmVxKSB7XG5cdHZhciBpZCA9IHdlYnBhY2tDb250ZXh0UmVzb2x2ZShyZXEpO1xuXHRyZXR1cm4gX193ZWJwYWNrX3JlcXVpcmVfXyhpZCk7XG59XG5mdW5jdGlvbiB3ZWJwYWNrQ29udGV4dFJlc29sdmUocmVxKSB7XG5cdGlmKCFfX3dlYnBhY2tfcmVxdWlyZV9fLm8obWFwLCByZXEpKSB7XG5cdFx0dmFyIGUgPSBuZXcgRXJyb3IoXCJDYW5ub3QgZmluZCBtb2R1bGUgJ1wiICsgcmVxICsgXCInXCIpO1xuXHRcdGUuY29kZSA9ICdNT0RVTEVfTk9UX0ZPVU5EJztcblx0XHR0aHJvdyBlO1xuXHR9XG5cdHJldHVybiBtYXBbcmVxXTtcbn1cbndlYnBhY2tDb250ZXh0LmtleXMgPSBmdW5jdGlvbiB3ZWJwYWNrQ29udGV4dEtleXMoKSB7XG5cdHJldHVybiBPYmplY3Qua2V5cyhtYXApO1xufTtcbndlYnBhY2tDb250ZXh0LnJlc29sdmUgPSB3ZWJwYWNrQ29udGV4dFJlc29sdmU7XG5tb2R1bGUuZXhwb3J0cyA9IHdlYnBhY2tDb250ZXh0O1xud2VicGFja0NvbnRleHQuaWQgPSBcIi4vc3JjL2ltYWdlcyBzeW5jIFxcXFwuKHBuZ3xqcGU/Z3xzdmd8d2VicHxqcGcpJFwiOyIsIi8vIFRoZSBtb2R1bGUgY2FjaGVcbnZhciBfX3dlYnBhY2tfbW9kdWxlX2NhY2hlX18gPSB7fTtcblxuLy8gVGhlIHJlcXVpcmUgZnVuY3Rpb25cbmZ1bmN0aW9uIF9fd2VicGFja19yZXF1aXJlX18obW9kdWxlSWQpIHtcblx0Ly8gQ2hlY2sgaWYgbW9kdWxlIGlzIGluIGNhY2hlXG5cdHZhciBjYWNoZWRNb2R1bGUgPSBfX3dlYnBhY2tfbW9kdWxlX2NhY2hlX19bbW9kdWxlSWRdO1xuXHRpZiAoY2FjaGVkTW9kdWxlICE9PSB1bmRlZmluZWQpIHtcblx0XHRyZXR1cm4gY2FjaGVkTW9kdWxlLmV4cG9ydHM7XG5cdH1cblx0Ly8gQ3JlYXRlIGEgbmV3IG1vZHVsZSAoYW5kIHB1dCBpdCBpbnRvIHRoZSBjYWNoZSlcblx0dmFyIG1vZHVsZSA9IF9fd2VicGFja19tb2R1bGVfY2FjaGVfX1ttb2R1bGVJZF0gPSB7XG5cdFx0Ly8gbm8gbW9kdWxlLmlkIG5lZWRlZFxuXHRcdC8vIG5vIG1vZHVsZS5sb2FkZWQgbmVlZGVkXG5cdFx0ZXhwb3J0czoge31cblx0fTtcblxuXHQvLyBFeGVjdXRlIHRoZSBtb2R1bGUgZnVuY3Rpb25cblx0X193ZWJwYWNrX21vZHVsZXNfX1ttb2R1bGVJZF0obW9kdWxlLCBtb2R1bGUuZXhwb3J0cywgX193ZWJwYWNrX3JlcXVpcmVfXyk7XG5cblx0Ly8gUmV0dXJuIHRoZSBleHBvcnRzIG9mIHRoZSBtb2R1bGVcblx0cmV0dXJuIG1vZHVsZS5leHBvcnRzO1xufVxuXG4iLCIvLyBkZWZpbmUgZ2V0dGVyIGZ1bmN0aW9ucyBmb3IgaGFybW9ueSBleHBvcnRzXG5fX3dlYnBhY2tfcmVxdWlyZV9fLmQgPSAoZXhwb3J0cywgZGVmaW5pdGlvbikgPT4ge1xuXHRmb3IodmFyIGtleSBpbiBkZWZpbml0aW9uKSB7XG5cdFx0aWYoX193ZWJwYWNrX3JlcXVpcmVfXy5vKGRlZmluaXRpb24sIGtleSkgJiYgIV9fd2VicGFja19yZXF1aXJlX18ubyhleHBvcnRzLCBrZXkpKSB7XG5cdFx0XHRPYmplY3QuZGVmaW5lUHJvcGVydHkoZXhwb3J0cywga2V5LCB7IGVudW1lcmFibGU6IHRydWUsIGdldDogZGVmaW5pdGlvbltrZXldIH0pO1xuXHRcdH1cblx0fVxufTsiLCJfX3dlYnBhY2tfcmVxdWlyZV9fLmcgPSAoZnVuY3Rpb24oKSB7XG5cdGlmICh0eXBlb2YgZ2xvYmFsVGhpcyA9PT0gJ29iamVjdCcpIHJldHVybiBnbG9iYWxUaGlzO1xuXHR0cnkge1xuXHRcdHJldHVybiB0aGlzIHx8IG5ldyBGdW5jdGlvbigncmV0dXJuIHRoaXMnKSgpO1xuXHR9IGNhdGNoIChlKSB7XG5cdFx0aWYgKHR5cGVvZiB3aW5kb3cgPT09ICdvYmplY3QnKSByZXR1cm4gd2luZG93O1xuXHR9XG59KSgpOyIsIl9fd2VicGFja19yZXF1aXJlX18ubyA9IChvYmosIHByb3ApID0+IChPYmplY3QucHJvdG90eXBlLmhhc093blByb3BlcnR5LmNhbGwob2JqLCBwcm9wKSkiLCIvLyBkZWZpbmUgX19lc01vZHVsZSBvbiBleHBvcnRzXG5fX3dlYnBhY2tfcmVxdWlyZV9fLnIgPSAoZXhwb3J0cykgPT4ge1xuXHRpZih0eXBlb2YgU3ltYm9sICE9PSAndW5kZWZpbmVkJyAmJiBTeW1ib2wudG9TdHJpbmdUYWcpIHtcblx0XHRPYmplY3QuZGVmaW5lUHJvcGVydHkoZXhwb3J0cywgU3ltYm9sLnRvU3RyaW5nVGFnLCB7IHZhbHVlOiAnTW9kdWxlJyB9KTtcblx0fVxuXHRPYmplY3QuZGVmaW5lUHJvcGVydHkoZXhwb3J0cywgJ19fZXNNb2R1bGUnLCB7IHZhbHVlOiB0cnVlIH0pO1xufTsiLCJ2YXIgc2NyaXB0VXJsO1xuaWYgKF9fd2VicGFja19yZXF1aXJlX18uZy5pbXBvcnRTY3JpcHRzKSBzY3JpcHRVcmwgPSBfX3dlYnBhY2tfcmVxdWlyZV9fLmcubG9jYXRpb24gKyBcIlwiO1xudmFyIGRvY3VtZW50ID0gX193ZWJwYWNrX3JlcXVpcmVfXy5nLmRvY3VtZW50O1xuaWYgKCFzY3JpcHRVcmwgJiYgZG9jdW1lbnQpIHtcblx0aWYgKGRvY3VtZW50LmN1cnJlbnRTY3JpcHQpXG5cdFx0c2NyaXB0VXJsID0gZG9jdW1lbnQuY3VycmVudFNjcmlwdC5zcmNcblx0aWYgKCFzY3JpcHRVcmwpIHtcblx0XHR2YXIgc2NyaXB0cyA9IGRvY3VtZW50LmdldEVsZW1lbnRzQnlUYWdOYW1lKFwic2NyaXB0XCIpO1xuXHRcdGlmKHNjcmlwdHMubGVuZ3RoKSBzY3JpcHRVcmwgPSBzY3JpcHRzW3NjcmlwdHMubGVuZ3RoIC0gMV0uc3JjXG5cdH1cbn1cbi8vIFdoZW4gc3VwcG9ydGluZyBicm93c2VycyB3aGVyZSBhbiBhdXRvbWF0aWMgcHVibGljUGF0aCBpcyBub3Qgc3VwcG9ydGVkIHlvdSBtdXN0IHNwZWNpZnkgYW4gb3V0cHV0LnB1YmxpY1BhdGggbWFudWFsbHkgdmlhIGNvbmZpZ3VyYXRpb25cbi8vIG9yIHBhc3MgYW4gZW1wdHkgc3RyaW5nIChcIlwiKSBhbmQgc2V0IHRoZSBfX3dlYnBhY2tfcHVibGljX3BhdGhfXyB2YXJpYWJsZSBmcm9tIHlvdXIgY29kZSB0byB1c2UgeW91ciBvd24gbG9naWMuXG5pZiAoIXNjcmlwdFVybCkgdGhyb3cgbmV3IEVycm9yKFwiQXV0b21hdGljIHB1YmxpY1BhdGggaXMgbm90IHN1cHBvcnRlZCBpbiB0aGlzIGJyb3dzZXJcIik7XG5zY3JpcHRVcmwgPSBzY3JpcHRVcmwucmVwbGFjZSgvIy4qJC8sIFwiXCIpLnJlcGxhY2UoL1xcPy4qJC8sIFwiXCIpLnJlcGxhY2UoL1xcL1teXFwvXSskLywgXCIvXCIpO1xuX193ZWJwYWNrX3JlcXVpcmVfXy5wID0gc2NyaXB0VXJsOyIsImltcG9ydCAnLi9tYWluLmNzcyc7XHJcblxyXG5pbXBvcnQge1xyXG4gIHBhcnNlVGltZVpvbmVVdGNPZmZzZXQsXHJcbiAgZm9ybWF0T3Blbk5vd1N0cmluZyxcclxuICBmb3JtYXRUaW1lXHJcbn0gZnJvbSBcIi9zcmMvbG9jYXRvci90aW1lXCI7XHJcblxyXG5mdW5jdGlvbiBpbXBvcnRBbGwocikge1xyXG4gICAgbGV0IGltYWdlcyA9IHt9O1xyXG4gICAgci5rZXlzKCkubWFwKChpdGVtLCBpbmRleCkgPT4geyBpbWFnZXNbaXRlbS5yZXBsYWNlKCcuLycsICcnKV0gPSByKGl0ZW0pOyB9KTtcclxuICAgIHJldHVybiBpbWFnZXM7XHJcbiAgfVxyXG4gIFxyXG4gIGNvbnN0IGltYWdlcyA9IGltcG9ydEFsbChyZXF1aXJlLmNvbnRleHQoJy4vaW1hZ2VzJywgZmFsc2UsIC9cXC4ocG5nfGpwZT9nfHN2Z3x3ZWJwfGpwZykkLykpO1xyXG4gIC8vIGNvbnN0IGNzcyA9IGltcG9ydEFsbChyZXF1aXJlLmNvbnRleHQoJy4vY3NzJywgZmFsc2UsIC9cXC4oY3NzKSQvKSk7XHJcblxyXG4gIFxyXG5cclxuIl0sInNvdXJjZVJvb3QiOiIifQ==